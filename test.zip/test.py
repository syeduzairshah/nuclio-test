def handler(context, event):
    print "\n\n\n\n\n---->>>>>>>>>>>>>>>>>>>>>>>\n\n\n"
    print("hello from uzair")
    return "Hello"
